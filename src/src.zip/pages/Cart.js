export default function Cart() {
  return (
    <div>Cart</div>
  )
}