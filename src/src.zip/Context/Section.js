import { useContext, useState } from 'react';
import { LevelContext } from './LevelContext.js';

import { assets } from '../assets/assets';


export default function Section({ children, isFancy }) {
   // const level = useContext(LevelContext);
   const[product,setProduct] = useState(null)
    const addProduct = (id) => {
        setProduct({id:1})
    } 

   const levelobj = {
    assets,
    addProduct
   }

    return (
      <section className={
        'section ' +
        (isFancy ? 'fancy' : '')
      }>
        <LevelContext.Provider value={levelobj}>
          {children}
        </LevelContext.Provider>
      </section>
    );
}
  